
<?php
require_once __DIR__ . "/../config/auth.php";

$judul = "Tambah Mahasiswa";
include __DIR__ . "/../template/header.php";
?>

<main class="form-mahasiswa-page">

    <section class="form-mahasiswa-card">

        <span class="form-kicker">STUDENT REGISTRATION</span>

        <h2>Tambah Data Mahasiswa ♡</h2>

        <p>Silakan isi data mahasiswa dengan lengkap dan benar.</p>

        <form action="../proses/proses_mahasiswa.php"
              method="POST"
              class="student-form"
              onsubmit="return validasiMahasiswa()">

            <label for="nama">Nama Lengkap</label>
            <input
                type="text"
                id="nama"
                name="nama"
                placeholder="Masukkan nama lengkap"
                required
            >

            <label for="nim">NIM</label>
            <input
                type="text"
                id="nim"
                name="nim"
                placeholder="Masukkan NIM"
                required
            >

            <label for="email">Email</label>
            <input
                type="email"
                id="email"
                name="email"
                placeholder="contoh@email.com"
                required
            >

            <label for="prodi">Program Studi</label>
            <input
                type="text"
                id="prodi"
                name="prodi"
                placeholder="Masukkan program studi"
                required
            >

            <button type="submit">
                Simpan Data ♡
            </button>

        </form>

    </section>

</main>

<script>
function validasiMahasiswa() {

    const nama = document.getElementById("nama").value.trim();
    const nim = document.getElementById("nim").value.trim();
    const email = document.getElementById("email").value.trim();
    const prodi = document.getElementById("prodi").value.trim();

    const polaEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (nama === "" || nim === "" || email === "" || prodi === "") {
        alert("Semua kolom wajib diisi!");
        return false;
    }

    if (!polaEmail.test(email)) {
        alert("Format email tidak valid!");
        return false;
    }

    return true;
}
</script>

<?php include __DIR__ . "/../template/footer.php"; ?>
```