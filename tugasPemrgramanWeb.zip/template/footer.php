<?php if (isset($_SESSION["user_id"])) { ?>

    <footer class="app-footer">
        <?= $copyright ?? "© 2026 - Ardianti Malika Putri"; ?>
        <br>
        <span><?= $teks_footer ?? "Made with ♡"; ?></span>
    </footer>

    </div>
</div>

<?php } else { ?>

    <footer class="login-footer">
        © 2026 - Ardianti Malika Putri
        <br>
        <span>Made with ♡</span>
    </footer>

    </div>

<?php } ?>

</body>
</html>