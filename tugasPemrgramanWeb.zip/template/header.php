<?php
$judul = $judul ?? "Ardianti Malika Putri";
$nama_tampilan = "Ardianti Malika Putri";
$halaman_aktif = basename($_SERVER["PHP_SELF"] ?? "");

$menu = [
    "dashboard.php" => ["Dashboard", "⌂"],
    "index.php" => ["Biodata", "♡"],
    "layout.php" => ["Layout Lab", "▦"],
    "data_mahasiswa.php" => ["Data Mahasiswa", "♧"],
    "form_mahasiswa.php" => ["Tambah Mahasiswa", "+"],
];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?= htmlspecialchars($judul); ?> | Ardianti Malika Putri</title>

    <link rel="stylesheet" href="/afteruts-main/assets/css/style.css?v=2">
</head>

<body>

<?php if (isset($_SESSION["user_id"])) { ?>

<div class="app-shell">

    <aside class="sidebar">

        <a class="brand" href="dashboard.php">
            <span class="brand-icon">✿</span>
            <span>Ardianti Malika Putri</span>
        </a>

        <div class="profile-mini">
            <img
                src="../assets/images/foto.jpg"
                alt="Foto Ardianti Malika Putri"
                onerror="this.style.display='none'"
            >

            <div class="profile-info">
                <strong>Ardianti Malika Putri</strong>
                <span>Mahasiswa Informatika</span>
            </div>
        </div>

        <nav class="side-menu">
            <?php foreach ($menu as $file => $item) { ?>
                <a
                    href="<?= htmlspecialchars($file); ?>"
                    class="<?= $halaman_aktif === $file ? 'active' : ''; ?>"
                >
                    <span class="menu-icon"><?= $item[1]; ?></span>
                    <span><?= htmlspecialchars($item[0]); ?></span>
                </a>
            <?php } ?>

            <a href="../proses/logout.php">
                <span class="menu-icon">↪</span>
                <span>Logout</span>
            </a>
        </nav>

        <div class="sidebar-note">
            Belajar, bertumbuh,<br>
            dan terus berkarya ♡
        </div>

    </aside>

    <div class="main-area">

        <header class="topbar">
            <div>
                <span class="eyebrow">WEB PROGRAMMING 1</span>
                <h1><?= htmlspecialchars($judul); ?></h1>
            </div>

            <div class="topbar-user">
                <span class="online-dot"></span>
                Halo, Ardianti!
            </div>
        </header>

<?php } else { ?>

    <div class="login-shell">
        <header class="login-brand">
            <span class="brand-icon">✿</span>
            <h1>Ardianti Malika Putri</h1>
            <p>Student Information System · Web Programming 1</p>
        </header>

<?php } ?>