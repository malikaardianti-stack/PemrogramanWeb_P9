# Proyek56 — PHP Native

File dikelompokkan berdasarkan kegunaannya. PHP, query, dan isi utama HTML
tetap berada di halaman masing-masing. Header dan footer dipakai bersama
melalui `include` dari folder `template/`.

```text
index.php                  → mengarahkan ke pages/index.php
pages/
  index.php                → biodata (file asli)
  index.html               → latihan HTML
  dashboard.php
  layout.php
  login.php
  data_mahasiswa.php
  form_mahasiswa.php
proses/
  proses_login.php
  proses_tambah.php
  logout.php
  buat_user.php
config/
  koneksi.php
  auth.php
template/
  header.php
  footer.php
assets/
  css/style.css
  images/foto.jpg
  images/profile.jpg
database/
  database.sql
```

Jalankan Apache dan MySQL, impor `database/database.sql`, lalu sesuaikan
koneksi di `config/koneksi.php`. Untuk membuat akun latihan, buka
`proses/buat_user.php` melalui URL proyek. Akun bawaan: `admin` / `admin123`.
Buka `index.php` di root proyek untuk masuk ke aplikasi.

Untuk lokasi proyek ini, buka `http://localhost/afteruts/afteruts/` atau
langsung `http://localhost/afteruts/afteruts/pages/login.php`.

File `.htaccess` membantu Apache mengalihkan URL lama (termasuk folder
`public/`) ke lokasi baru. Pengalihan memakai status 307 agar pengiriman
form POST tetap membawa datanya. Link dan form di kode menggunakan lokasi
baru secara langsung. File ini juga membuat `index.php` diutamakan ketika
folder `pages/` dibuka, karena di sana ada latihan `index.html` juga.
Jika proyek dipindah atau memakai virtual host, sesuaikan `RewriteBase`
di `.htaccess` dengan path URL proyek (misalnya `/` untuk root virtual host).

Setelah pindah folder, yang disesuaikan hanya path include, link, form,
redirect, dan aset. Contoh dari file dalam `pages/`:

```php
require_once __DIR__ . "/../config/auth.php";
require __DIR__ . "/../config/koneksi.php";
```

`__DIR__` menunjuk folder file PHP tersebut, sedangkan `..` berarti naik
satu folder. Path pada `href`, `src`, dan `action` dihitung dari URL halaman
yang dibuka di browser. Redirect dalam `config/auth.php` juga dihitung dari
URL pemanggilnya, yaitu halaman di `pages/` atau proses di `proses/`.

Untuk membuat halaman PHP dengan template, ikuti pola ini:

```php
<?php
require_once __DIR__ . "/../config/auth.php";

$judul = "Halaman Baru";
include __DIR__ . "/../template/header.php";
?>

<main>
    <section>
        <h2>Isi Halaman</h2>
        <p>Tulis isi halaman di sini.</p>
    </section>
</main>

<?php include __DIR__ . "/../template/footer.php"; ?>
```

`header.php` berisi pembuka HTML, judul tab, CSS, dan banner halaman.
`footer.php` berisi footer dan penutup HTML. Menu navigasi tetap berada di
masing-masing halaman agar contoh sidebar dan menu biodata tetap mudah dibaca.
Pengecekan login, query, dan redirect dikerjakan sebelum include header agar
belum ada HTML yang dikirim saat PHP perlu mengirim header HTTP.

Variabel `$judul` menentukan judul tab dan banner. Bila perlu, halaman dapat
mengisi `$judul_header` untuk judul banner yang berbeda, `$deskripsi` untuk
teks di bawahnya, dan `$keterangan` untuk paragraf tambahan. Footer memakai
`$teks_footer` jika diisi dan dapat menampilkan `$copyright`. Semua teks ini
di-escape oleh template; isi variabel dengan teks biasa, bukan tag HTML.

Keenam halaman PHP di `pages/` sudah menggunakan template ini.
`pages/index.html` tetap menjadi latihan HTML statis; PHP `include` dipakai
pada file `.php`.
